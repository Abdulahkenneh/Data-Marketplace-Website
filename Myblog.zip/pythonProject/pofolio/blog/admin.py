from django.contrib import admin
from .models import Person,BlogPost,Courses
# Register your models here.
admin.site.register(Person)
admin.site.register(BlogPost)
admin.site.register(Courses)