from django.shortcuts import render
from django.http import HttpRequest,request
# Create your views here.

def index(request):
    return render(request,"blog/home.html",{})


# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import LoginForm, RegistrationForm,BlogPostForm,TopicForm
from .models import Topic,Courses,BlogPost
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required




def blog_detail_view(request):
    return render(request,"blog/blog.html")



def course_view(request):
    return render(request,template_name="blog/courses.html")
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('blog:home')  # Redirect to the homepage after login
    else:
        form = LoginForm()
    return render(request, 'blog/login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('blog:home')  # Redirect to home page after registration
    else:
        form = RegistrationForm()
    return render(request, 'blog/register.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('blog:home')  # Redirect to the homepage after logout


# views.py
from django.shortcuts import render, redirect
from .forms import BlogPostForm, TopicForm

@login_required(login_url="/login")
def create_blogpost(request):
    if request.method == 'POST':
        form = BlogPostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('blog:home')  # Redirect after successful form submission
    else:
        form = BlogPostForm()
    return render(request, 'blog/create_blogpost.html', {'form': form})

@login_required(login_url="/login/")
def create_topic(request):
    if request.method == 'POST':
        form = TopicForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('blog:topic')  # Redirect after successful form submission
    else:
        form = TopicForm()
    return render(request, 'blog/create_topic.html', {'form': form})

def all_topics(request):
    topics = Topic.objects.all()
    courses = Courses.objects.all()
    posts = BlogPost.objects.all()
    contex ={"topics":topics,'courses':courses,'posts':posts}
    return render(request, 'blog/all_topic.html', context=contex)

@login_required(login_url="/login")
def topic_detail(request, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id)
    return render(request, 'blog/topic_detail.html', {'topic': topic})

def courses_detail(request,course_id):
    courses = get_object_or_404(Courses,pk=course_id)
    contex={"courses":courses}
    return render(request,template_name="blog/course_detail.html",context=contex)