
from django.db import models

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager,User
from django.db import models


class PersonManager(BaseUserManager):
    def create_user(self, username, password=None):
        if not username:
            raise ValueError('The Username field must be set')

        user = self.model(username=username)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password):
        user = self.create_user(username=username, password=password)
        user.is_superuser = True
        user.is_staff = True
        user.save(using=self._db)
        return user


class Person(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=150, unique=True)
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    objects = PersonManager()
    USERNAME_FIELD = 'username'
    is_staff = models.BooleanField(default=False)
    def __str__(self):
        return self.firstname



class Topic(models.Model):
    name = models.CharField(max_length=100)


    def __str__(self):
        return self.name

class Courses(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
class BlogPost(models.Model):
    person_name = models.CharField(max_length=100)
    topic = models.CharField(max_length=100)
    post_date = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='blog_images/')
    text = models.TextField()
    course = models.ForeignKey(Courses, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.person_name}'s Post on {self.post_date} in {self.course}"
