# forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Person,BlogPost,Topic

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

class RegistrationForm(UserCreationForm):
    class Meta:
        model = Person
        fields = ['firstname', 'username', 'password1', 'password2']


# forms.py

class BlogPostForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ['person_name', 'image','topic', 'text', 'course']

class TopicForm(forms.ModelForm):
    class Meta:
        model = Topic
        fields = ['name']
