from django.urls import path

# urls.py
from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

urlpatterns = [
    path('',views.index,name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('courses/',views.course_view,name="courses"),
    path("courses/<int:course_id>/",views.courses_detail,name="course_detail"),
    path('logout/', LogoutView.as_view(), name='logout'),
    path("topic/",views.create_topic,name="topic"),
    path("entry/",views.create_blogpost,name="entry"),
    path("topics",views.all_topics,name="topics"),
    path('topics/<int:topic_id>/', views.topic_detail, name='topic_detail'),
    # Other URL patterns...
]

app_name="blog"